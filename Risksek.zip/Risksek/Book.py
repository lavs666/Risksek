# Define the Book class
class Book:
    def __init__(self, title, author, isbn):
        self.title = title
        self.author = author
        self.isbn = isbn

    def display_info(self):
        print(f"Title: {self.title}\nAuthor: {self.author}\nISBN: {self.isbn}")

# Define the Library class
class Library:
    def __init__(self):
        self.books = []

    def add_book(self, book):
        if isinstance(book, Book):
            self.books.append(book)
            print(f"Book '{book.title}' added to the library.")
        else:
            print("Invalid book object. Please provide a valid Book instance.")

    def display_all_books(self):
        if not self.books:
            print("No books in the library.")
        else:
            print("Books in the library:")
            for book in self.books:
                print(f"- {book.title} by {book.author}")

    def search_book_by_title(self, title):
        for book in self.books:
            if book.title.lower() == title.lower():
                return book
        return None

# Define the EBook subclass
class EBook(Book):
    def __init__(self, title, author, isbn, file_format):
        super().__init__(title, author, isbn)
        self.file_format = file_format

    def display_info(self):
        super().display_info()
        print(f"File Format: {self.file_format}")


# Test the classes
try:
    book1 = Book("The Great Gatsby", "F. Scott Fitzgerald", "9780142437419")
    book2 = EBook("The Catcher in the Rye", "J.D. Salinger", "9780241950425", "PDF")

    library = Library()
    library.add_book(book1)
    library.add_book(book2)

    library.display_all_books()

    search_title = "The Catcher in the Rye"
    found_book = library.search_book_by_title(search_title)
    if found_book:
        print(f"Book '{search_title}' found:")
        found_book.display_info()
    else:
        print(f"Book '{search_title}' not found in the library.")
except Exception as e:
    print(f"An error occurred: {e}")
