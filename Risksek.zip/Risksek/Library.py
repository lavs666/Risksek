from flask import Flask, request, jsonify
# Flask App for API Interface
app = Flask(__name__)
library = Library()

# API routes
@app.route('/add_book', methods=['POST'])
def add_book():
    data = request.get_json()
    try:
        title = data['title']
        author = data['author']
        isbn = data['isbn']
        book = Book(title, author, isbn)
        library.add_book(book)
        return jsonify({"message": f"Book '{title}' added to the library."})
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@app.route('/list_books', methods=['GET'])
def list_books():
    books_data = [{"title": book.title, "author": book.author, "isbn": book.isbn} for book in library.books]
    return jsonify({"books": books_data})

@app.route('/delete_book', methods=['DELETE'])
def delete_book():
    data = request.get_json()
    try:
        title = data['title']
        book = library.search_book_by_title(title)
        if book:
            library.books.remove(book)
            return jsonify({"message": f"Book '{title}' deleted from the library."})
        else:
            return jsonify({"error": f"Book '{title}' not found in the library."}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 400
    
# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
